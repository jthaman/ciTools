# Copyright (C) 2017 Institute for Defense Analyses
#
# This file is part of ciTools.
#
# ciTools is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# ciTools is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with ciTools. If not, see <http://www.gnu.org/licenses/>.

#' Confidence Intervals for Generalized Linear Models
#'
#' This function is one of the methods for \code{add_ci}, and is
#' called automatically when \code{add_ci} is used on a \code{fit} of
#' class \code{glm}. Confidence Intervals are determined by making an
#' interval on the scale of the linear predictor, then applying the
#' inverse link function from the model fit to transform the linear
#' level confidence intervals to the response level.
#'
#' @param tb A tibble or Data Frame.
#' @param fit An object of class \code{glm}.
#' @param alpha A real number between 0 and 1. Controls the confidence
#'     level of the interval estimates.
#' @param names NULL or character vector of length two. If
#'     \code{NULL}, confidence bounds will automatically be named by
#'     \code{add_ci}, otherwise, the lower confidence bound will be
#'     named \code{names[1]} and the upper confidence bound will be
#'     named \code{names[2]}.
#' @param type A string, currently \code{"type" = "parametric"} is the
#'     only supported method.
#' @param response A logical. The default is \code{TRUE}. If
#'     \code{TRUE}, the confidence intervals will be determined for
#'     the expected response, if \code{FALSE}, confidence intervals
#'     will be made on the scale of the linear predictor.
#' @param ... Additional arguments.
#' 
#' @return A tibble, \code{tb}, with predicted values, upper and lower
#'     confidence bounds attached.
#'
#' @seealso \code{{\link{add_pi.glm}}} for prediction intervals for
#'     \code{glm} objects. \code{\link{add_probs.glm}} for conditional
#'     probabilities of \code{glm} objects, and
#'     \code{\link{add_quantile.glm}} for response quantiles of
#'     \code{glm} objects.
#'
#' @examples
#' # Poisson Regression
#' fit <- glm(dist ~ speed, data = cars, family = "poisson")
#' add_ci(cars, fit)
#' add_ci(cars, fit, alpha = 0.5)
#' add_ci(cars, fit, alpha = 0.5, names = c("lwr", "upr"))
#' # Logistic Regression
#' fit2 <- glm(I(dist > 30) ~ speed, data = cars, family = "binomial")
#' dat <- cbind(cars, I(cars$dist > 30))
#' add_ci(dat, fit)
#' add_ci(dat, fit, alpha = 0.5)
#' add_ci(dat, fit, alpha = 0.5, response = FALSE)
#' add_ci(dat, fit, alpha = 0.5, names = c("lwr", "upr"))
#'
#' @export

add_ci.glm <- function(tb, fit, alpha = 0.05, names = NULL,
                      response = TRUE, type = "parametric", ...){

    if (grepl("numerically 0 or 1", list(warnings())))
        warning ("If there is perfect separation in your logistic regression, you shouldn't trust these confidence intervals")
    if (is.null(names)){
        names[1] <- paste("LCB", alpha/2, sep = "")
        names[2] <- paste("UCB", 1 - alpha/2, sep = "")
    }
    if ((names[1] %in% colnames(tb))) {
        warning ("These CIs may have already been appended to your dataframe. Overwriting.")
    }
    if (type == "boot")
        stop ("not yet implemented")
    else if (type == "parametric")
        parametric_ci_glm(tb, fit, alpha, names, response)
    else
        if(!(type %in% c("boot", "parametric"))) stop("Incorrect interval type specified!")

}

parametric_ci_glm <- function(tb, fit, alpha, names, response){
    out <- predict(fit, tb, se.fit = TRUE)

    crit_val <- qt(p = 1 - alpha/2, df = fit$df.residual)
    inverselink <- fit$family$linkinv
    if (response){
        upr <- inverselink(out$fit + crit_val * out$se.fit)
        lwr <- inverselink(out$fit - crit_val * out$se.fit)
        pred <- inverselink(out$fit)
    }else{
        upr <- out$fit + crit_val * out$se.fit
        lwr <- out$fit - crit_val * out$se.fit
        pred <- out$fit
    }
    if(is.null(tb[["pred"]]))
        tb[["pred"]] <- pred
    tb[[names[1]]] <- lwr
    tb[[names[2]]] <- upr
    tibble::as_data_frame(tb)

}


## parametric_ci_glm <- function(tb, fit, alpha, names, type = "response"){

##     inverselink <- fit$family$linkinv
##     if(type == "response"){
##         out <- glm_ci_response(tb, fit, alpha, inverselink) %>%
##             plyr::rename(c("lwr" = names[1], "upr" = names[2])) %>%
##             select(-.se)
##     }

##     if(type == "link"){
##         out <- glm_ci_linear_predictor(tb, fit, alpha) %>%
##             plyr::rename(c("lwr" = names[1], "upr" = names[2])) %>%
##             select(-.se)
##     }
##     if(!(type %in% c("response", "link"))) top("Incorrect interval type specified!")
##     out
## }

## glm_ci_response <- function(tb, fit, alpha, ilink){

##     if(is.null(tb[["pred"]]))
##         tb <- modelr::add_predictions(tb, fit)
##     tb %>%
##         add_standard_error(fit) %>%
##         mutate(
##             lwr = ilink(pred + qt(alpha/2, df = fit$df.residual) * .se),
##             upr = ilink(pred + qt(1 - alpha/2, df = fit$df.residual) * .se)
##         )

## }

## glm_ci_linear_predictor <- function(tb, fit, alpha){

##     if(is.null(tb[["pred"]]))
##         tb <- modelr::add_predictions(tb, fit)
##     tb %>%
##         add_standard_error(fit) %>%
##         mutate(
##             lwr = pred + qt(alpha/2, df = fit$df.residual) * .se,
##             upr = pred + qt(1 - alpha/2, df = fit$df.residual) * .se
##         )

## }
