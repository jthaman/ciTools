## TODO : add quantile method for lmer objects
