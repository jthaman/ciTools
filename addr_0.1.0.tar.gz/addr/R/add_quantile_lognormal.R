## TODO : add quantile method for log-linear models

