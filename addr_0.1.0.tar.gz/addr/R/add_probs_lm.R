#' @export

add_probs.lm <- function(tb, fit, quant, name = NULL,
                         comparison = "<", log_response = FALSE){

    if (is.null(name) && comparison == "<")
        name <- paste("Pr(Y < ", quant, ")", sep="")
    if (is.null(name) && comparison == ">")
        name <- paste("Pr(Y > ", quant, ")", sep="")
    if ((name %in% colnames(tb))) {
        warning ("These probabilities may have already been appended to your dataframe")
        return(tb)
    }

    if (log_response)
        quant <- log(quant)

    out <- predict(fit, tb, interval = "prediction", se.fit = TRUE)
    fitted <- out$fit[,1]
    residual_df <- out$df
    se_fitted <- out$se.fit
    resid_var <- out$residual.scale^2
    se_pred <- sqrt(resid_var + se_fitted^2)
    t_quantile <- (quant - fitted) / se_pred
    if (comparison == "<")
        t_prob <- pt(q = t_quantile, df = residual_df)
    if (comparison == ">")
        t_prob <- 1 - pt(q = t_quantile, df = residual_df)
    if (is.null(tb[["pred"]]))
        tb[["pred"]] <- fitted
    if (is.null(tb[[name]]))
        tb[[name]] <- t_prob
    as_data_frame(tb)
}
